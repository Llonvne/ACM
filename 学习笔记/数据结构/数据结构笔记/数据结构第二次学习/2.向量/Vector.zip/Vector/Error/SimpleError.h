//
// Created by 华邵钶 on 2022/2/27.
//

#ifndef SIMPLEERROR_H
#define SIMPLEERROR_H
void error_message(const char * message);
#endif //SIMPLEERROR_H
